openfig('untitled4.fig');
yline(3115);